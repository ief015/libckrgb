#ifdef __cplusplus

extern "C" {
#include "libckrgb.h"
}

#endif